-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2022 at 12:28 PM
-- Server version: 5.5.24-log
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineshopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(10) NOT NULL,
  `username` char(15) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `password`) VALUES
(12, 'mimi', 'MIMI');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_view`
-- (See below for the actual view)
--
CREATE TABLE `admin_view` (
`ID` int(10)
,`username` char(15)
,`password` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `customer_names` char(15) DEFAULT NULL,
  `phonenumber` int(10) DEFAULT NULL,
  `location` varchar(15) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `customer_update_trigger` AFTER UPDATE ON `customer` FOR EACH ROW update order_table set customer_id=customer_id where customer.customer_id=customer_id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `delete customer trigger` AFTER DELETE ON `customer` FOR EACH ROW delete from customer where customer.customer_id=customer_id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_trigger_to_order_table` AFTER INSERT ON `customer` FOR EACH ROW insert into order_table (customer_id) values (new.customer_id)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
-- (See below for the actual view)
--
CREATE TABLE `customer_view` (
`customer_id` int(10)
,`customer_names` char(15)
,`phonenumber` int(10)
,`location` varchar(15)
,`email` varchar(40)
,`username` varchar(20)
,`password` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pro_Id` int(10) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `quantity` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `order_table_view`
-- (See below for the actual view)
--
CREATE TABLE `order_table_view` (
`order_id` int(10)
,`customer_id` int(11)
,`pro_Id` int(10)
,`date` datetime
,`quantity` int(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_Id` int(10) NOT NULL,
  `customer_id` int(10) DEFAULT NULL,
  `pro_Id` int(10) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `order_id` int(10) DEFAULT NULL,
  `amount` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `payment_view`
-- (See below for the actual view)
--
CREATE TABLE `payment_view` (
`pay_Id` int(10)
,`customer_id` int(10)
,`pro_Id` int(10)
,`date` datetime
,`order_id` int(10)
,`amount` int(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pro_Id` int(10) NOT NULL,
  `pro_name` char(15) DEFAULT NULL,
  `pro_price` int(10) DEFAULT NULL,
  `pro_category` varchar(15) DEFAULT NULL,
  `pro_quantity` int(10) DEFAULT NULL,
  `pro_quality` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `products_view`
-- (See below for the actual view)
--
CREATE TABLE `products_view` (
`pro_Id` int(10)
,`pro_name` char(15)
,`pro_price` int(10)
,`pro_category` varchar(15)
,`pro_quantity` int(10)
,`pro_quality` int(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subquerry`
-- (See below for the actual view)
--
CREATE TABLE `subquerry` (
`pro_Id` int(10)
,`pro_name` char(15)
,`pro_price` int(10)
,`pro_category` varchar(15)
,`pro_quantity` int(10)
,`pro_quality` int(20)
);

-- --------------------------------------------------------

--
-- Structure for view `admin_view`
--
DROP TABLE IF EXISTS `admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_view`  AS  select `admin`.`ID` AS `ID`,`admin`.`username` AS `username`,`admin`.`password` AS `password` from `admin` ;

-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view`  AS  select `customer`.`customer_id` AS `customer_id`,`customer`.`customer_names` AS `customer_names`,`customer`.`phonenumber` AS `phonenumber`,`customer`.`location` AS `location`,`customer`.`email` AS `email`,`customer`.`username` AS `username`,`customer`.`password` AS `password` from `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `order_table_view`
--
DROP TABLE IF EXISTS `order_table_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `order_table_view`  AS  select `order_table`.`order_id` AS `order_id`,`order_table`.`customer_id` AS `customer_id`,`order_table`.`pro_Id` AS `pro_Id`,`order_table`.`date` AS `date`,`order_table`.`quantity` AS `quantity` from `order_table` ;

-- --------------------------------------------------------

--
-- Structure for view `payment_view`
--
DROP TABLE IF EXISTS `payment_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_view`  AS  select `payment`.`pay_Id` AS `pay_Id`,`payment`.`customer_id` AS `customer_id`,`payment`.`pro_Id` AS `pro_Id`,`payment`.`date` AS `date`,`payment`.`order_id` AS `order_id`,`payment`.`amount` AS `amount` from `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `products_view`
--
DROP TABLE IF EXISTS `products_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `products_view`  AS  select `products`.`pro_Id` AS `pro_Id`,`products`.`pro_name` AS `pro_name`,`products`.`pro_price` AS `pro_price`,`products`.`pro_category` AS `pro_category`,`products`.`pro_quantity` AS `pro_quantity`,`products`.`pro_quality` AS `pro_quality` from `products` ;

-- --------------------------------------------------------

--
-- Structure for view `subquerry`
--
DROP TABLE IF EXISTS `subquerry`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subquerry`  AS  select `products`.`pro_Id` AS `pro_Id`,`products`.`pro_name` AS `pro_name`,`products`.`pro_price` AS `pro_price`,`products`.`pro_category` AS `pro_category`,`products`.`pro_quantity` AS `pro_quantity`,`products`.`pro_quality` AS `pro_quality` from `products` where (`products`.`pro_quantity` <= (select avg(`products`.`pro_quantity`) from `products`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `pro_Id` (`pro_Id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_Id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `pro_Id` (`pro_Id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pro_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pro_Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_table`
--
ALTER TABLE `order_table`
  ADD CONSTRAINT `order_table_ibfk_1` FOREIGN KEY (`pro_Id`) REFERENCES `products` (`pro_Id`),
  ADD CONSTRAINT `order_table_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `order_table` (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
